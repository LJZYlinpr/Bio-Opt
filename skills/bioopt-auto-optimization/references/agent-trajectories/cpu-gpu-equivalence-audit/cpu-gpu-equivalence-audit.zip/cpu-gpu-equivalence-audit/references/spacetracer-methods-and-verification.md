# SpaceTracer：方法复现、CPU/GPU 静态分区与来源核验附录

> 用途：为 `cpu-gpu-equivalence-audit` 提供一个“只有论文、没有可用源码/数据时”的可复用案例。本文档只记录论文文本中出现的流程、参数和项目核验结果；不把论文声明写成已经运行或已经复现。

## 1. 来源与页码映射

- 题目：`Detection of Somatic Point Mutations Directly from Spatial Transcriptomics Enables in vivo Spatiotemporal Lineage Tracing`
- DOI：`10.64898/2026.02.04.703493`
- 论文状态：PDF 首页注明“currently under consideration in Nature”；属于预印本，不能按同行评审后的最终论文处理。
- 本地输入：原始 PDF 的精确路径由项目记录保存；本次核验的原始文件为 51 页，SHA-256：`a190a8ee1e7586f08cabccfcfb553ac7317b0f91450a6ca323d657d6133f3119`。
- 页码结构：
  - 第 1–19 页：正文与 Main Figures；
  - 第 20–36 页：Methods；
  - 第 37–47 页：Extended Data Figures；
  - 第 48–51 页：References。
- 分卷文件及哈希见 `SpaceTracer_分卷/SpaceTracer_分卷_manifest.json`；分卷是重新封装的 PDF，不能用分卷字节哈希代替原始 PDF 哈希。

## 2. 论文描述的端到端流程

1. 以 GRCh38 为参考，对 WGS、scRNA/snRNA 和 Visium 数据分别进行比对/预处理。
2. 从过滤后的 BAM 进行 VAF prescan，先用深度、ALT 支持、VAF、群体频率和经验背景噪声过滤候选位点。
3. 在 UMI 层级聚合 reads，用 Bayes 后验得到每个 UMI 的共识等位基因和联合错误率。
4. 用分层 Bayes 模型在个体/spot 层面对 `refhom`、`het`、`althom`、`mosaic` 四类基因型进行推断，并利用表达/空间聚类形成 cluster-level 先验。
5. 为候选位点提取 98 个 read-level、RNA-specific、空间分布和深度标准化特征。
6. 用带空间特征和不带空间特征的两个 Random Forest 模型预测高可信体细胞 SNV。
7. 用 192 类 RNA 突变谱的 NMF/启发式 hFDR 分析去除裂解、化学修饰和 RNA-editing 类伪影，再应用硬过滤器。
8. 对保留的 SNV 做功能注释、突变签名、突变率估计、谱系/系统发育重建，并与 CNV、细胞类型、基因表达、空间配准和 CellChat 结果联合分析。

## 3. 预处理和候选位点筛选

### 3.1 论文中给出的版本

| 环节 | 工具/版本 | 关键设置 |
|---|---|---|
| WGS 比对 | BWA-MEM v0.7.17 | GRCh38 |
| WGS 去重复 | GATK MarkDuplicates v4.2.6.1 | 检测并去除 duplicates |
| scRNA/snRNA 比对 | CellRanger v7.1.0 | GRCh38 |
| 单细胞聚类/降维 | Seurat v5.1.0 | LogNormalize；2,000 variable features；回归线粒体基因百分比；RANN；保留前 30 PCs |
| Visium 比对 | SpaceRanger v2.0.1 | GRCh38 |
| BAM 读段预过滤 | 论文流程 | mismatch ≤5；MapQ ≥255 |

### 3.2 VAF prescan

论文给出的命令为：

```text
samtools mpileup --excl-flags 0 -s -B -Q 0 -q 0 -d 200000 -f reference.fa sample.bam
```

候选位点规则：

- 总 read depth `<30×`：排除；
- alternative read depth `<5`：排除；
- VAF `>0.3` 或 `<0.1%`：排除；
- 从 gnomAD 获取群体等位基因频率；
- 对样本 VAF `<5%` 且 gnomAD 频率为 0 的低频候选进行伪影筛查；
- 论文把经验背景噪声设为 `0.3%`，对候选做单尾二项检验；VAF 相对 0.3% 不显著（`p>0.05`）者排除。

**审查提示：** `-Q 0 -q 0` 的 prescan 命令与后面 WGS 验证所用的严格质量参数不是同一套设置；复现时必须把两者分开记录，不能用一条命令替换另一条。

## 4. UMI 层级聚合与分层 Bayes 基因分型

### 4.1 UMI 聚合

- 每个 UMI 的先验等位基因概率均设为 `1/4`，等位基因为 A/T/C/G。
- 以 Bayes 后验计算 UMI 属于各等位基因的概率。
- 论文设定 `α=0.5`，用于平衡真实等位基因/测序错误路径与 PCR 错误路径。
- 以最大后验概率的等位基因为 consensus allele；联合错误率为 `E(j)=1-P(j|D_UMI)`。
- 该步骤含 UMI 分组、等位基因计数和后验归一化；如果迁移到 GPU，必须保持 UMI 分组顺序、等位基因顺序、归约顺序和浮点精度。

### 4.2 分层基因分型

- 基因分型前再次过滤 mismatch `>5` 或 MapQ `<255` 的 reads。
- 四类基因型：`het`、`refhom`、`althom`、`mosaic`。
- 先验来自 dbSNP 与 gnomAD 的 population allele frequency；论文正文提到一个默认体细胞突变率 `μ`，但当前文本提取把其指数显示为 `10$E/bp`，指数/排版无法可靠恢复。
- `refhom`、`het`、`althom` 的理论 MAF 分别为 0、0.5、1；`mosaic` 的 MAF 假设在 `[0,1]` 均匀分布。
- 用 Bernoulli sampling 近似 PCR 扩增错误、测序错误以及 ref/alt read depth bias。
- 不能从当前文本提取结果重建公式（3）–（9）的完整排版。复现实现应回看原 PDF 公式或作者代码；在此之前，不应把 `μ` 或公式系数写入程序作为“已核实参数”。

### 4.3 空间/表达 cluster 先验

- 默认候选聚类工具：SpaGCN v1.2.7、GraphST v1.1.1；二者同时使用表达与空间位置。
- 用 scikit-learn v1.2.2 的 DBSCAN 拆分不连通空间域。
- 只有 1–2 个 spot 的小域并入相邻且属于同一 cluster 的域。
- cluster-level mutant allele frequency 用于更新先验；spot 的 mosaic genotype posterior `>0.5` 且至少含一个 mutant allele 时，判定 spot 为 mutant。

## 5. 98 个特征、深度截断与机器学习模型

### 5.1 特征类别

论文称共 98 个特征，覆盖：

- read-level：mapping quality 差异、read alignment positional bias、base quality、read 内 base position 分布、每条 read 的 mismatch 数、含 indel read 比例、soft-clipped read 比例、homopolymer 相关过滤等；
- RNA-specific：strand bias、RADAR/REDIportal/DARNED 注释的 RNA-editing 潜势、UMI-level allele concordance、gene-expression correlated artifacts、allele-specific expression（ASE）等；
- spatial：mutant 与 non-mutant spots 的 KS 检验，以及 mutant spot 的 Moran’s I 空间自相关；
- 深度无关化：使用标准化效应量而非原始检验统计量，示例为 rank-biserial correlation（RBC）。

文本提取出的 RBC 公式对应常见形式 `RBC = 2U/(n_ref*n_alt)-1`；公式周边的下标在 PDF 文本层有乱码，编码实现前应以原始公式为准。

### 5.2 深度截断和随机性

- 每个位点在提取特征前做 depth cap：深度 `>2000×` 时随机下采样到恰好 `2000×`，否则使用全部 reads。
- 这一步是复现和 CPU/GPU 等价审查的高风险边界：仅设置相同 seed 不足以证明跨后端逐元素相同。应优先把随机下采样索引预先固化为显式输入，或比较并记录 RNG 状态/抽样索引。

### 5.3 训练集和两个模型

- 训练/测试资料：论文称超过 18 个 slides、7 个独立个体；每个公开空间数据集至少有两类正交验证来源。
- 评估方式：leave-one-donor-out cross-validation；测试 donor 的所有样本不得进入训练集。
- 训练两个 Random Forest 模型：
  1. spatial-preserved：仅使用具有清晰空间组织的两个皮肤癌数据集和一个乳腺癌数据集；
  2. spatial-feature-free：面向缺少清晰空间组织或存在迁移的样本，去掉以下五个特征：`pass_spatial_test`、`mut_vs_nonmut_spots_KS_p`、`mut_vs_nonmut_spots_KS_s`、`mut_vs_nonmut_spots_MI_p`、`mut_vs_nonmut_spots_MI_s`。
- 论文称约 96% 的伪影突变可由 in-silico haplotype phasing 识别；真正的低频体细胞突变预期只位于一个 haplotype，双 haplotype 同位点出现更可能是错配/伪影。

## 6. Artifact signature 与硬过滤

### 6.1 突变签名伪影过滤

- 从 ultra-low-frequency variants 构建 192 类、含三核苷酸上下文和链方向的 RNA mutation profile；低频定义为仅由一个 UMI 支持且 VAF `<5%`。
- 用 NMF v0.28 提取三个主要伪影签名，ccfindR v1.18.0 的 Variational Bayesian Factorization 用于选择签名数。
- 论文解释的主要模式：C>T（裂解/热诱导胞嘧啶脱氨）、G>T（氧化损伤）、A>G（RNA editing 可能性）。
- 每个候选计算 heuristic FDR（hFDR）；`hFDR ≥0.8` 的候选排除。
- 论文方法正文称用于签名的数据为“101 slices of 50 individuals”，而 Extended Data Figure 2 图注称为“107 slices of 50 independent individuals”。这是需要保留的内部不一致，不能擅自选一个数字作为事实。
- 背景 AAF 用 Beta(a,b) 建模，真实 SNV AAF 用 `[0,1]` 均匀先验；具体公式在当前 PDF 文本提取中不可直接复原。

### 6.2 硬过滤器

- gnomAD AF `>0.01%`：排除；
- ASE：若基因含显著等位基因失衡的 germline SNP（双尾二项检验 `p≤0.05`），且候选 SNV 的 VAF 与附近 germline SNP 的 allele fraction 不显著不同（`p>0.05`），则排除；
- 移除 RADAR、REDIportal、DARNED 注释的 RNA-editing 位点；
- 额外移除所有 A>G 突变；
- 移除 227 个经典 imprinting genes 中的位点；
- 移除位于或邻近长度 ≥6 bp homopolymer 的位点；
- 使用 33 个非肿瘤样本构建 panel of normals，排除其中的 recurrent artifacts/germline variants。

## 7. 突变签名、突变率与验证基准

### 7.1 突变签名

- SigProfilerAssignment v0.2.6：提取并绘制组织特异性 96 类谱；
- deconstructSigs v1.9.0：与 COSMIC signatures 比较；
- 论文限制的 signatures：
  - skin：SBS1、SBS5、SBS7a、SBS7b、SBS7c、SBS7d、SBS38；
  - brain：SBS1、SBS2、SBS5、SBS18；
  - breast：SBS1、SBS5、SBS40。

### 7.2 突变率

- 单细胞：按每个 cell 检出的 mutation 数除以该 cell callable genomic region 长度，再对 cells 汇总。
- 空间转录组没有单细胞 barcode，使用 lower/upper bound：
  - callable region：该 spot 非零覆盖，且该位点至少在 30 个 spots 中有非零覆盖；
  - lower bound：把同一 spot 中不同 UMI 的突变视为来自同一 cell；
  - upper bound：把每个 unique UMI 视为不同 cell；
  - 论文称约 60–80% 突变由单一 UMI 支持，两个界限通常只差约 10–20%，后续分析采用更保守的 lower bound。
- 论文引用的 DNA-seq 对照范围：tumor skin 0.1–380/Mb，normal skin 0.4–12/Mb，normal brain 0.167–1.3/Mb，normal breast 0.1–0.4/Mb。它们是论文采用的文献范围，不是本项目测得的范围。

### 7.3 竞争工具和参数

| 工具 | 论文中版本/日期 | 关键参数或后处理 |
|---|---|---|
| SComatic | 2024-01-10 版本 | 第一步 `n_trim=5`、`max_nM=5`、`max_NH=1`；第二步 `min_bq=30`；其余默认 |
| Monopogen | v1.5.0 | 预处理、germline SNV、putative somatic 默认；后过滤 `SVM_pos_score>0.5`、`LDrefine_merged_score>0.25`、`0.1<BAF_alt<0.5`、`Dep_ref>2`、`Dep_alt>2` |
| SpatialSNV | v1.1.3 | 按 chromosome 拆 BAM；`SplitChromBAM`、`PrepareBAMforCalling`、`SNVCalling`；排除 MNV；默认参数；额外要求 ≥30 个非零覆盖 spots、≥3 supporting UMIs、VAF<30% |

**比较限制：** 论文称 SpatialSNV 每样本常产生数万突变，多数为极低频，因此公开基准的手工 read-quality 交叉验证没有将其纳入 precision/recall 对比。这会影响不同工具之间的可比性，应在报告中保留。

### 7.4 WGS 交叉验证

- BCC benchmark：相邻切片，一片做空间转录组，另一片 WGA 后做 PCR-free 深度 WGS，平均约 `200×`。
- Mutect2（GATK v4.2.2.0）+ panel-of-normals；MosaicForecast 默认过滤。
- 进入转录组可验证集合的阈值：至少 30 个 UMI-covered spots、至少 3 个 alternative-supporting UMIs、VAF `≤0.3`。
- 高质量 allele depth 的 samtools v1.21 命令使用 `-s -B -Q 20 -q 30 --excl-flags SECONDARY,QCFAIL -d 200000`。
- 验证：top mutant allele 与第二高等位基因做单尾 Fisher 检验 `p≤0.05`；VAF 显著低于 50%（单尾二项检验 `p≤0.05`）以排除疑似 germline。
- 公开基准还使用三名研究者独立 IGV v2.18.2 检查、细胞类型分布偏倚检验以及相邻切片确认；出现 ALT read 末端富集、ALT read mismatch 过多或 ≥6 bp homopolymer 时判为 artifact。

## 8. 谱系、CNV 与下游空间分析

### 8.1 伪空间谱系基准

- 两个带 knock-in CRISPR barcode 的 LUAD scRNA-seq 数据集；
- CytoSpace v1.1.0 投影到 10x Visium HD 人肺癌空间布局；限制 cell→spot 与 spot→cell 均为严格一对一；
- scRNA 中先用 MosaiSC 识别突变；空间分型使用 SpaceTracer；
- PhyloSOLID v1.0.0，默认参数重建 phylogeny。

### 8.2 CNV

- inferCNV v1.20.0：用非 keratinocyte、非 epithelial spots 作为 reference；连续 segment ratio 离散为 6 states，再合并为 loss（1、2）、neutral（3）、gain（4–6）；非 neutral 统称 copy changed。
- CalicoST：preprocessing → `estimate_tumor_proportion` → 主模块；最多 3 个主要 subclones（`n_clones=3`），其余默认；GRCh38。

### 8.3 注释和通路

- ANNOVAR；GENCODE v46；dbNSFP 中的 PolyPhen2 HumanDiv 预测；
- KOBAS v3.0.3：KEGG、Reactome、KEGG Disease、GO；
- 细胞类型：论文正文同时出现 `Spotify`、`spotiphy`、`Spotiphy` 等写法。参数上下文显示使用的是 Spotiphy/spotiphy 生态，但名称与版本需以作者代码或补充表最终核对：deconvolution v0.1.1，CellChat 输入处理写为 Spotiphy v0.3.1；
- SingleR v2.0.0：cSCC 缺少预定义注释时投影到 Blueprint/ENCODE。
- deconvolution：`spotiphy.deconvolution.estimation_proportion(n_epochs=8000)`；基于 total UMI 的线性模型估计绝对细胞数；55 μm spot，最大预测细胞数 25；simulation 参数 `batch_effect_sigma=0.1`、`zero_proportion=0.3`、`additive_noise_sigma=0.05`。

### 8.4 TSK、EMT、克隆区域和切片配准

- TSK/tumor fitness score：SCANPY `sc.tl.score_genes`；同表达 bin 中取 100 个 background genes；全基因表达范围分 30 bins。
- EMT：gseapy v1.1.4 的 ssGSEA，MSigDB `HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION`。
- cSCC-1 tumor region：SpaGCN v1.2.7，TSK score `>0.2`；SciPy v1.13.1 `cKDTree` 取 6 nearest neighbors，至少 2 个 tumor neighbors 才标 Ct。
- Cp/Cn：SpaGCN 先取 normal epithelium，再用 founder mutation 作 seed；scikit-learn v1.4.1 `NearestNeighbors`，6 neighbors，不含自身扩展区域。
- 相邻切片：STAligner v1.0.0，以 landmark domain 的 MNN 和 ICP 做 3D spatial registration。

### 8.5 DEG、fitness、CellChat 和密度图

- Scanpy v1.9.8 `rank_genes_groups()`：双尾 Wilcoxon；至少表达于 3 个 cells；adjusted p≤0.05、log2FC>0.1。
- DLPFC 12 slices：去除空间信息后用 Harmony 去 batch；Seurat `FindMarkers` v5.2.0 的 `wilcox_limma`，p<0.05、`|FC|>1.5`。
- phylogenetic fitness：local branching index（LBI），包含树的 forward/backward pass 和指数衰减时间尺度；论文未给出足以复现的完整时间尺度参数。
- fitness-DE：每个基因至少在 10 cells 中检测到；按 cell-level library size 归一化，表达为 `log(1+e)`；加入 detected-gene 数 size factor；比较 full/reduced Gaussian linear models，LRT 1 df；另算 top/bottom fitness quantile 的 log2FC。
- CellChat v2.1.2，输入为 Spotiphy v0.3.1 处理的空间数据；按 phylogenetic fitness 中位数分 high/low；DBSCAN v1.2.4 + KNN；网格 `ε=30..60`、步长 5，`minPts=5..12`；每组保留 spot 数最多的空间 cluster。
- 密度图：seaborn v0.13.2 `kdeplot`，Scott rule；局部邻域用 scikit-learn v1.7 `NearestNeighbors`。这些步骤依赖浮点 KDE、邻居排序和统计后处理，不能默认 GPU/CPU 字节一致。

## 9. CPU/GPU 静态分区（没有源码时只能写“候选”）

| 区块 | 论文/常见实现中的当前倾向 | GPU 候选 | 主要风险 | 结论等级 |
|---|---|---|---|---|
| FASTQ/BAM/FASTA、比对、去重复、mpileup | 外部命令/文件 I/O/传统工具链 | 只有在替换为已验证 GPU 工具时才考虑 | 格式、过滤旗标、排序和版本差异 | CPU/外部工具，未证明 GPU |
| UMI 分组与 A/T/C/G 计数 | Python/R + 分组/聚合 | 固定形状的 allele-count 与后验批量计算 | group-by、变长 UMI、归约顺序、错误模型 | 候选 GPU；需逐 UMI 检验 |
| Bayes genotype | 数组化似然/后验 | 位点×genotype 的 dense 批量运算 | log-sum-exp、先验、浮点归约 | 候选 GPU；不能先验 A 级 |
| cluster 先验、SpaGCN/GraphST/DBSCAN | 图、KNN、空间域和 Python/R 包 | 已固定图后的 dense message passing | 动态 KNN、DBSCAN、排序、边顺序 | 高风险，先固定图再评估 |
| 98 特征 | read 级统计、RNA 注释、KS/Moran | 独立位点/批量统计可候选 | read layout、缺失值、检验实现、空间邻接 | 混合；需按特征核验 |
| Random Forest 预测 | CPU sklearn/R 生态较常见 | 批量推理可迁移 | 树遍历、浮点阈值、特征列顺序 | 候选 GPU/CPU均可，结果需验证 |
| NMF/签名暴露/PCA | 矩阵分解和线性代数 | dense matrix kernels | 初始化、收敛、归约和随机初始化 | 候选 GPU；仅 B/C 预期 |
| ANNOVAR/数据库/硬过滤 | 文件/数据库/规则逻辑 | 不应为 GPU 优先项 | 数据库版本和注释版本 | CPU |
| PhyloSOLID/LBI/树 | 图/树结构和分支遍历 | 批量距离或固定矩阵部分可候选 | 稀疏、动态树、顺序依赖 | 高风险 |
| inferCNV/CalicoST | R/Python/矩阵+分段/子克隆 | 部分 dense 线性代数可候选 | 参考选取、离散化、子克隆优化 | 混合；需源码/环境 |
| Spotiphy/SingleR/Scanpy/Seurat | R/Python 包、统计、模拟 | 仅已确认后端的 dense 部分 | 随机模拟、背景基因抽样、包版本 | CPU/混合，未证明 |
| STAligner MNN+ICP | 邻居搜索、配准 | 固定矩阵运算可候选 | MNN、排序、ICP 迭代和收敛 | 高风险 |
| CellChat/KNN/KDE/线性模型 | 网络、邻居、统计和绘图 | 大矩阵部分可候选 | 网络构建、聚类、KDE、排序 | CPU/混合，未证明 |

**无源码时的硬性结论：** 可以做上表的静态分区，不能声称 SpaceTracer 已经在 GPU 上运行、已经加速，或其 CPU/GPU 输出等价。任何迁移都应先获得可访问实现、精确输入、依赖版本、随机抽样索引和输出定义。

## 10. 论文声明 vs 项目核验状态

| 对象 | 论文声明/提供的入口 | 项目核验结果 | 复现含义 |
|---|---|---|---|
| 代码 | `https://github.com/douymLab/SpaceTracer`；称 MIT、预计 2026-03-01 或正式接收前公开 | 前一轮 GitHub API 对该仓库返回 404；组织页存在但未发现该仓库 | 代码未验证可取得；不能按源码已公开处理 |
| 本研究 WGS/ST 数据 | SRA BioProject `PRJNA1396783` | NCBI SRA/BioProject 搜索记录为 “No items found” | 不能把论文中的 reviewer 参数化链接当作公开数据入口；不要传播其中的访问参数 |
| GEO 数据 | 论文列出 GSE158328、GSE144240、GSE225475、GSE220978、GSE237183、GSE195665、GSE171351、GSE176078、GSE274641、GSE161363 | `GSE158328` 页面前一轮被 reCAPTCHA 拦截；其余未在该轮逐一确认 | 仅可记录为论文列出的 accession，不能宣称当前均可下载 |
| EGA | `EGAS00001006124` | 研究页存在，但数据集为 controlled access | 需要合法申请/授权，不能绕过访问控制 |
| 10x LUAD Visium HD | 论文给出的公开数据集页面 | 页面存在，但当前访问出现隐私确认/重定向 | 入口存在不等于本会话已拿到数据 |
| Globus | `jhpce#spatialDLPFC`、`jhpce#HumanPilot10x` | 论文列出入口；本轮未完成可下载性确认 | 需要保留“待核验”状态 |

**隐私/安全规则：** 论文中带有 reviewer 参数的 URL 可能包含临时访问信息；本附录只保留 accession 和不带参数的基础入口，不复制、解析或传播 reviewer 参数。凭据文件不读取、不修改、不纳入交付。

## 11. 复现与等价审查的准入门槛

在声称“可运行”“已加速”或“结果不变”前，至少补齐：

1. 作者代码或等价、可审计的实现；
2. 精确输入文件和原始字节 SHA-256；
3. GRCh38/注释/数据库版本；
4. BAM 过滤旗标、MapQ/mismatch/depth/VAF 阈值；
5. UMI 抽样与 depth cap 的 RNG 状态或显式抽样索引；
6. 模型文件、训练 donor 划分、特征列顺序和 RF 配置；
7. 输出定义：候选位点表、spot genotype、突变谱、树、空间标签和统计结果；
8. 小规模 smoke test 和逐阶段一致性记录。

若只满足论文文本而不满足上述门槛，报告用语应为：

- “根据论文的静态流程，以下是 GPU 候选区块”；
- “代码/数据入口未验证，未进行端到端性能测试”；
- “CPU/GPU 字节级等价未证明”；
- “公式或版本存在文本提取/来源不一致，待作者代码或原始补充材料核对”。

禁止使用：

- “论文用了 GPU，所以该步骤已经适合 GPU”；
- “相同 seed 即可保证 CPU/GPU 相同”；
- “allclose 通过，所以输出严格相同”；
- “链接写在论文里，所以数据已经公开可下载”。
